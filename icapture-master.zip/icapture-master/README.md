# icapture
capture images from webcam using aforge library
