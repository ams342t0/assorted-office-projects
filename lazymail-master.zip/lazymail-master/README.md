# lazymail
a very crude imap email client using limilabs mail.dll
