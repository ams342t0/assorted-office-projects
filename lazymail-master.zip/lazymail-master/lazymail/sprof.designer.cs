﻿namespace lazymail
{
	partial class profile
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtID = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.txtName = new System.Windows.Forms.TextBox();
			this.txtSchool = new System.Windows.Forms.TextBox();
			this.txtShirtSize = new System.Windows.Forms.TextBox();
			this.txtEmail1 = new System.Windows.Forms.TextBox();
			this.txtEmail2 = new System.Windows.Forms.TextBox();
			this.cbSex = new System.Windows.Forms.ComboBox();
			this.cbLevel = new System.Windows.Forms.ComboBox();
			this.cbCenter = new System.Windows.Forms.ComboBox();
			this.cbSchedule = new System.Windows.Forms.ComboBox();
			this.cmdClose = new System.Windows.Forms.Button();
			this.cmdERF = new System.Windows.Forms.Button();
			this.txtRemarks = new System.Windows.Forms.TextBox();
			this.Remarks = new System.Windows.Forms.Label();
			this.chkQualified = new System.Windows.Forms.CheckBox();
			this.chkDepSlip = new System.Windows.Forms.CheckBox();
			this.chkEmailed = new System.Windows.Forms.CheckBox();
			this.txtProfile = new System.Windows.Forms.TextBox();
			this.label11 = new System.Windows.Forms.Label();
			this.cmdUpdate = new System.Windows.Forms.Button();
			this.txtDepSlip = new System.Windows.Forms.TextBox();
			this.label12 = new System.Windows.Forms.Label();
			this.cmdViewProfile = new System.Windows.Forms.Button();
			this.cmdViewDepslip = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// txtID
			// 
			this.txtID.Location = new System.Drawing.Point(83, 6);
			this.txtID.Name = "txtID";
			this.txtID.Size = new System.Drawing.Size(341, 20);
			this.txtID.TabIndex = 0;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(30, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(48, 13);
			this.label1.TabIndex = 12;
			this.label1.Text = "STUDID";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(43, 33);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(35, 13);
			this.label2.TabIndex = 13;
			this.label2.Text = "Name";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(53, 57);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(25, 13);
			this.label3.TabIndex = 14;
			this.label3.Text = "Sex";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(253, 56);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(33, 13);
			this.label4.TabIndex = 15;
			this.label4.Text = "Level";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(38, 85);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(40, 13);
			this.label5.TabIndex = 16;
			this.label5.Text = "School";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(40, 109);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(38, 13);
			this.label6.TabIndex = 17;
			this.label6.Text = "Center";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(27, 133);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(51, 13);
			this.label7.TabIndex = 18;
			this.label7.Text = "Shirt Size";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(145, 134);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(52, 13);
			this.label8.TabIndex = 19;
			this.label8.Text = "Schedule";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(37, 159);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(41, 13);
			this.label9.TabIndex = 20;
			this.label9.Text = "Email 1";
			this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(244, 159);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(41, 13);
			this.label10.TabIndex = 21;
			this.label10.Text = "Email 2";
			// 
			// txtName
			// 
			this.txtName.Location = new System.Drawing.Point(83, 30);
			this.txtName.Name = "txtName";
			this.txtName.Size = new System.Drawing.Size(341, 20);
			this.txtName.TabIndex = 1;
			// 
			// txtSchool
			// 
			this.txtSchool.Location = new System.Drawing.Point(83, 81);
			this.txtSchool.Name = "txtSchool";
			this.txtSchool.Size = new System.Drawing.Size(341, 20);
			this.txtSchool.TabIndex = 4;
			// 
			// txtShirtSize
			// 
			this.txtShirtSize.Location = new System.Drawing.Point(83, 130);
			this.txtShirtSize.Name = "txtShirtSize";
			this.txtShirtSize.Size = new System.Drawing.Size(48, 20);
			this.txtShirtSize.TabIndex = 6;
			// 
			// txtEmail1
			// 
			this.txtEmail1.Location = new System.Drawing.Point(82, 156);
			this.txtEmail1.Name = "txtEmail1";
			this.txtEmail1.Size = new System.Drawing.Size(136, 20);
			this.txtEmail1.TabIndex = 8;
			// 
			// txtEmail2
			// 
			this.txtEmail2.Location = new System.Drawing.Point(288, 156);
			this.txtEmail2.Name = "txtEmail2";
			this.txtEmail2.Size = new System.Drawing.Size(136, 20);
			this.txtEmail2.TabIndex = 9;
			// 
			// cbSex
			// 
			this.cbSex.FormattingEnabled = true;
			this.cbSex.Location = new System.Drawing.Point(83, 54);
			this.cbSex.Name = "cbSex";
			this.cbSex.Size = new System.Drawing.Size(135, 21);
			this.cbSex.TabIndex = 2;
			// 
			// cbLevel
			// 
			this.cbLevel.FormattingEnabled = true;
			this.cbLevel.Location = new System.Drawing.Point(289, 54);
			this.cbLevel.Name = "cbLevel";
			this.cbLevel.Size = new System.Drawing.Size(135, 21);
			this.cbLevel.TabIndex = 3;
			// 
			// cbCenter
			// 
			this.cbCenter.FormattingEnabled = true;
			this.cbCenter.Location = new System.Drawing.Point(83, 105);
			this.cbCenter.Name = "cbCenter";
			this.cbCenter.Size = new System.Drawing.Size(341, 21);
			this.cbCenter.TabIndex = 5;
			// 
			// cbSchedule
			// 
			this.cbSchedule.FormattingEnabled = true;
			this.cbSchedule.Location = new System.Drawing.Point(200, 130);
			this.cbSchedule.Name = "cbSchedule";
			this.cbSchedule.Size = new System.Drawing.Size(224, 21);
			this.cbSchedule.TabIndex = 7;
			// 
			// cmdClose
			// 
			this.cmdClose.Location = new System.Drawing.Point(349, 286);
			this.cmdClose.Name = "cmdClose";
			this.cmdClose.Size = new System.Drawing.Size(75, 23);
			this.cmdClose.TabIndex = 11;
			this.cmdClose.Text = "&CLOSE";
			this.cmdClose.UseVisualStyleBackColor = true;
			this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
			// 
			// cmdERF
			// 
			this.cmdERF.Location = new System.Drawing.Point(268, 286);
			this.cmdERF.Name = "cmdERF";
			this.cmdERF.Size = new System.Drawing.Size(75, 23);
			this.cmdERF.TabIndex = 10;
			this.cmdERF.Text = "&ERF";
			this.cmdERF.UseVisualStyleBackColor = true;
			this.cmdERF.Click += new System.EventHandler(this.cmdERF_Click);
			// 
			// txtRemarks
			// 
			this.txtRemarks.Location = new System.Drawing.Point(82, 182);
			this.txtRemarks.Name = "txtRemarks";
			this.txtRemarks.Size = new System.Drawing.Size(341, 20);
			this.txtRemarks.TabIndex = 22;
			// 
			// Remarks
			// 
			this.Remarks.AutoSize = true;
			this.Remarks.Location = new System.Drawing.Point(29, 185);
			this.Remarks.Name = "Remarks";
			this.Remarks.Size = new System.Drawing.Size(49, 13);
			this.Remarks.TabIndex = 23;
			this.Remarks.Text = "Remarks";
			this.Remarks.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// chkQualified
			// 
			this.chkQualified.AutoSize = true;
			this.chkQualified.Location = new System.Drawing.Point(83, 258);
			this.chkQualified.Name = "chkQualified";
			this.chkQualified.Size = new System.Drawing.Size(67, 17);
			this.chkQualified.TabIndex = 24;
			this.chkQualified.Text = "Qualified";
			this.chkQualified.UseVisualStyleBackColor = true;
			// 
			// chkDepSlip
			// 
			this.chkDepSlip.AutoSize = true;
			this.chkDepSlip.Location = new System.Drawing.Point(156, 258);
			this.chkDepSlip.Name = "chkDepSlip";
			this.chkDepSlip.Size = new System.Drawing.Size(82, 17);
			this.chkDepSlip.TabIndex = 25;
			this.chkDepSlip.Text = "Deposit Slip";
			this.chkDepSlip.UseVisualStyleBackColor = true;
			// 
			// chkEmailed
			// 
			this.chkEmailed.AutoSize = true;
			this.chkEmailed.Location = new System.Drawing.Point(251, 258);
			this.chkEmailed.Name = "chkEmailed";
			this.chkEmailed.Size = new System.Drawing.Size(63, 17);
			this.chkEmailed.TabIndex = 26;
			this.chkEmailed.Text = "Emailed";
			this.chkEmailed.UseVisualStyleBackColor = true;
			// 
			// txtProfile
			// 
			this.txtProfile.Location = new System.Drawing.Point(82, 208);
			this.txtProfile.Name = "txtProfile";
			this.txtProfile.Size = new System.Drawing.Size(279, 20);
			this.txtProfile.TabIndex = 27;
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(42, 211);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(36, 13);
			this.label11.TabIndex = 28;
			this.label11.Text = "Profile";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// cmdUpdate
			// 
			this.cmdUpdate.Location = new System.Drawing.Point(187, 286);
			this.cmdUpdate.Name = "cmdUpdate";
			this.cmdUpdate.Size = new System.Drawing.Size(75, 23);
			this.cmdUpdate.TabIndex = 29;
			this.cmdUpdate.Text = "UP&DATE";
			this.cmdUpdate.UseVisualStyleBackColor = true;
			this.cmdUpdate.Click += new System.EventHandler(this.cmdUpdate_Click);
			// 
			// txtDepSlip
			// 
			this.txtDepSlip.Location = new System.Drawing.Point(82, 232);
			this.txtDepSlip.Name = "txtDepSlip";
			this.txtDepSlip.Size = new System.Drawing.Size(279, 20);
			this.txtDepSlip.TabIndex = 30;
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(30, 235);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(48, 13);
			this.label12.TabIndex = 31;
			this.label12.Text = "Payment";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// cmdViewProfile
			// 
			this.cmdViewProfile.Location = new System.Drawing.Point(367, 206);
			this.cmdViewProfile.Name = "cmdViewProfile";
			this.cmdViewProfile.Size = new System.Drawing.Size(57, 23);
			this.cmdViewProfile.TabIndex = 32;
			this.cmdViewProfile.Text = "View";
			this.cmdViewProfile.UseVisualStyleBackColor = true;
			this.cmdViewProfile.Click += new System.EventHandler(this.cmdViewProfile_Click);
			// 
			// cmdViewDepslip
			// 
			this.cmdViewDepslip.Location = new System.Drawing.Point(367, 231);
			this.cmdViewDepslip.Name = "cmdViewDepslip";
			this.cmdViewDepslip.Size = new System.Drawing.Size(57, 23);
			this.cmdViewDepslip.TabIndex = 33;
			this.cmdViewDepslip.Text = "View";
			this.cmdViewDepslip.UseVisualStyleBackColor = true;
			this.cmdViewDepslip.Click += new System.EventHandler(this.cmdViewDepslip_Click);
			// 
			// profile
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(433, 318);
			this.Controls.Add(this.cmdViewDepslip);
			this.Controls.Add(this.cmdViewProfile);
			this.Controls.Add(this.txtDepSlip);
			this.Controls.Add(this.label12);
			this.Controls.Add(this.cmdUpdate);
			this.Controls.Add(this.txtProfile);
			this.Controls.Add(this.label11);
			this.Controls.Add(this.chkEmailed);
			this.Controls.Add(this.chkDepSlip);
			this.Controls.Add(this.chkQualified);
			this.Controls.Add(this.txtRemarks);
			this.Controls.Add(this.Remarks);
			this.Controls.Add(this.cmdERF);
			this.Controls.Add(this.cmdClose);
			this.Controls.Add(this.cbSchedule);
			this.Controls.Add(this.cbCenter);
			this.Controls.Add(this.cbLevel);
			this.Controls.Add(this.cbSex);
			this.Controls.Add(this.txtEmail2);
			this.Controls.Add(this.txtEmail1);
			this.Controls.Add(this.txtShirtSize);
			this.Controls.Add(this.txtSchool);
			this.Controls.Add(this.txtName);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtID);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "profile";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "PROFILE";
			this.Load += new System.EventHandler(this.profile_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox txtID;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.TextBox txtName;
		private System.Windows.Forms.TextBox txtSchool;
		private System.Windows.Forms.TextBox txtShirtSize;
		private System.Windows.Forms.TextBox txtEmail1;
		private System.Windows.Forms.TextBox txtEmail2;
		private System.Windows.Forms.ComboBox cbSex;
		private System.Windows.Forms.ComboBox cbLevel;
		private System.Windows.Forms.ComboBox cbCenter;
		private System.Windows.Forms.ComboBox cbSchedule;
		private System.Windows.Forms.Button cmdClose;
		private System.Windows.Forms.Button cmdERF;
		private System.Windows.Forms.TextBox txtRemarks;
		private System.Windows.Forms.Label Remarks;
		private System.Windows.Forms.CheckBox chkQualified;
		private System.Windows.Forms.CheckBox chkDepSlip;
		private System.Windows.Forms.CheckBox chkEmailed;
		private System.Windows.Forms.TextBox txtProfile;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Button cmdUpdate;
		private System.Windows.Forms.TextBox txtDepSlip;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Button cmdViewProfile;
		private System.Windows.Forms.Button cmdViewDepslip;
	}
}

