﻿namespace lazymail
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.lvemails = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.txtbody = new System.Windows.Forms.TextBox();
            this.listImages = new System.Windows.Forms.ListBox();
            this.cMenu1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.rEFERENCEFILEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vIEWFILEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtscanfile = new System.Windows.Forms.TextBox();
            this.txtemailaddress = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtsearch = new System.Windows.Forms.TextBox();
            this.lvstudents = new System.Windows.Forms.ListView();
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.sbSource = new System.Windows.Forms.ToolStripStatusLabel();
            this.mailcount = new System.Windows.Forms.ToolStripStatusLabel();
            this.sbText = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnuUpdate = new System.Windows.Forms.ToolStripMenuItem();
            this.vIEWSCANToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.mAILERToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.gETMAILSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.qUICKEMAILToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cOPYEMAILToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.uPDATEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pROFILEToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sETTINGSToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sEARCHToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bYNAMEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bYEMAILToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aBOUTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ofd = new System.Windows.Forms.OpenFileDialog();
            this.fbd = new System.Windows.Forms.FolderBrowserDialog();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.cMenu1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer1.Location = new System.Drawing.Point(0, 28);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer4);
            this.splitContainer1.Size = new System.Drawing.Size(1285, 428);
            this.splitContainer1.SplitterDistance = 720;
            this.splitContainer1.TabIndex = 0;
            // 
            // splitContainer2
            // 
            this.splitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.lvemails);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.splitContainer3);
            this.splitContainer2.Size = new System.Drawing.Size(720, 428);
            this.splitContainer2.SplitterDistance = 239;
            this.splitContainer2.TabIndex = 0;
            // 
            // lvemails
            // 
            this.lvemails.CheckBoxes = true;
            this.lvemails.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader11,
            this.columnHeader4});
            this.lvemails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvemails.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvemails.FullRowSelect = true;
            this.lvemails.GridLines = true;
            this.lvemails.HideSelection = false;
            this.lvemails.Location = new System.Drawing.Point(0, 0);
            this.lvemails.MultiSelect = false;
            this.lvemails.Name = "lvemails";
            this.lvemails.Size = new System.Drawing.Size(716, 235);
            this.lvemails.TabIndex = 1;
            this.lvemails.UseCompatibleStateImageBehavior = false;
            this.lvemails.View = System.Windows.Forms.View.Details;
            this.lvemails.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.lvemails_ColumnClick);
            this.lvemails.ItemSelectionChanged += new System.Windows.Forms.ListViewItemSelectionChangedEventHandler(this.lvemails_ItemSelectionChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "ID";
            this.columnHeader1.Width = 69;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "from";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader2.Width = 161;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "subject";
            this.columnHeader3.Width = 160;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "body";
            this.columnHeader11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader11.Width = 157;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "status";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader4.Width = 97;
            // 
            // splitContainer3
            // 
            this.splitContainer3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.txtbody);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.listImages);
            this.splitContainer3.Size = new System.Drawing.Size(720, 185);
            this.splitContainer3.SplitterDistance = 393;
            this.splitContainer3.TabIndex = 0;
            // 
            // txtbody
            // 
            this.txtbody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtbody.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbody.Location = new System.Drawing.Point(0, 0);
            this.txtbody.Multiline = true;
            this.txtbody.Name = "txtbody";
            this.txtbody.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtbody.Size = new System.Drawing.Size(389, 181);
            this.txtbody.TabIndex = 5;
            // 
            // listImages
            // 
            this.listImages.ContextMenuStrip = this.cMenu1;
            this.listImages.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listImages.FormattingEnabled = true;
            this.listImages.Location = new System.Drawing.Point(0, 0);
            this.listImages.Name = "listImages";
            this.listImages.Size = new System.Drawing.Size(319, 181);
            this.listImages.TabIndex = 2;
            this.listImages.SelectedIndexChanged += new System.EventHandler(this.listImages_SelectedIndexChanged);
            // 
            // cMenu1
            // 
            this.cMenu1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rEFERENCEFILEToolStripMenuItem,
            this.vIEWFILEToolStripMenuItem});
            this.cMenu1.Name = "cMenu1";
            this.cMenu1.Size = new System.Drawing.Size(186, 52);
            // 
            // rEFERENCEFILEToolStripMenuItem
            // 
            this.rEFERENCEFILEToolStripMenuItem.Name = "rEFERENCEFILEToolStripMenuItem";
            this.rEFERENCEFILEToolStripMenuItem.Size = new System.Drawing.Size(185, 24);
            this.rEFERENCEFILEToolStripMenuItem.Text = "REFERENCE FILE";
            this.rEFERENCEFILEToolStripMenuItem.Click += new System.EventHandler(this.rEFERENCEFILEToolStripMenuItem_Click);
            // 
            // vIEWFILEToolStripMenuItem
            // 
            this.vIEWFILEToolStripMenuItem.Name = "vIEWFILEToolStripMenuItem";
            this.vIEWFILEToolStripMenuItem.Size = new System.Drawing.Size(185, 24);
            this.vIEWFILEToolStripMenuItem.Text = "VIEW FILE";
            // 
            // splitContainer4
            // 
            this.splitContainer4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(0, 0);
            this.splitContainer4.Name = "splitContainer4";
            this.splitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.label3);
            this.splitContainer4.Panel1.Controls.Add(this.label2);
            this.splitContainer4.Panel1.Controls.Add(this.label1);
            this.splitContainer4.Panel1.Controls.Add(this.txtscanfile);
            this.splitContainer4.Panel1.Controls.Add(this.txtemailaddress);
            this.splitContainer4.Panel1.Controls.Add(this.txtName);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.txtsearch);
            this.splitContainer4.Panel2.Controls.Add(this.lvstudents);
            this.splitContainer4.Size = new System.Drawing.Size(561, 428);
            this.splitContainer4.SplitterDistance = 104;
            this.splitContainer4.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(4, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Scan file";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(4, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Email";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(4, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Name";
            // 
            // txtscanfile
            // 
            this.txtscanfile.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtscanfile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtscanfile.Location = new System.Drawing.Point(74, 77);
            this.txtscanfile.Name = "txtscanfile";
            this.txtscanfile.Size = new System.Drawing.Size(480, 23);
            this.txtscanfile.TabIndex = 2;
            // 
            // txtemailaddress
            // 
            this.txtemailaddress.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtemailaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemailaddress.Location = new System.Drawing.Point(74, 51);
            this.txtemailaddress.Name = "txtemailaddress";
            this.txtemailaddress.Size = new System.Drawing.Size(480, 23);
            this.txtemailaddress.TabIndex = 1;
            // 
            // txtName
            // 
            this.txtName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(74, 25);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(480, 23);
            this.txtName.TabIndex = 0;
            // 
            // txtsearch
            // 
            this.txtsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearch.Location = new System.Drawing.Point(3, 3);
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(359, 23);
            this.txtsearch.TabIndex = 3;
            this.txtsearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtsearch_KeyDown);
            // 
            // lvstudents
            // 
            this.lvstudents.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lvstudents.CheckBoxes = true;
            this.lvstudents.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader6,
            this.columnHeader5});
            this.lvstudents.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvstudents.FullRowSelect = true;
            this.lvstudents.GridLines = true;
            this.lvstudents.HideSelection = false;
            this.lvstudents.Location = new System.Drawing.Point(0, 29);
            this.lvstudents.MultiSelect = false;
            this.lvstudents.Name = "lvstudents";
            this.lvstudents.Size = new System.Drawing.Size(558, 282);
            this.lvstudents.TabIndex = 4;
            this.lvstudents.UseCompatibleStateImageBehavior = false;
            this.lvstudents.View = System.Windows.Forms.View.Details;
            this.lvstudents.ItemSelectionChanged += new System.Windows.Forms.ListViewItemSelectionChangedEventHandler(this.lvstudents_ItemSelectionChanged);
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "name";
            this.columnHeader8.Width = 171;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "center";
            this.columnHeader9.Width = 148;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "school";
            this.columnHeader10.Width = 143;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Shirt";
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Level";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sbSource,
            this.mailcount,
            this.sbText});
            this.statusStrip1.Location = new System.Drawing.Point(0, 456);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1285, 25);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // sbSource
            // 
            this.sbSource.Name = "sbSource";
            this.sbSource.Size = new System.Drawing.Size(52, 20);
            this.sbSource.Text = "source";
            // 
            // mailcount
            // 
            this.mailcount.Name = "mailcount";
            this.mailcount.Size = new System.Drawing.Size(75, 20);
            this.mailcount.Text = "mailcount";
            // 
            // sbText
            // 
            this.sbText.Name = "sbText";
            this.sbText.Size = new System.Drawing.Size(151, 20);
            this.sbText.Text = "toolStripStatusLabel1";
            this.sbText.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuUpdate,
            this.sEARCHToolStripMenuItem,
            this.aBOUTToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1285, 28);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mnuUpdate
            // 
            this.mnuUpdate.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vIEWSCANToolStripMenuItem1,
            this.mAILERToolStripMenuItem1,
            this.gETMAILSToolStripMenuItem,
            this.qUICKEMAILToolStripMenuItem1,
            this.cOPYEMAILToolStripMenuItem1,
            this.uPDATEToolStripMenuItem,
            this.pROFILEToolStripMenuItem1,
            this.sETTINGSToolStripMenuItem1});
            this.mnuUpdate.Name = "mnuUpdate";
            this.mnuUpdate.Size = new System.Drawing.Size(47, 24);
            this.mnuUpdate.Text = "&FILE";
            // 
            // vIEWSCANToolStripMenuItem1
            // 
            this.vIEWSCANToolStripMenuItem1.Name = "vIEWSCANToolStripMenuItem1";
            this.vIEWSCANToolStripMenuItem1.ShortcutKeyDisplayString = "F2";
            this.vIEWSCANToolStripMenuItem1.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.vIEWSCANToolStripMenuItem1.Size = new System.Drawing.Size(246, 24);
            this.vIEWSCANToolStripMenuItem1.Text = "VIEW SCAN";
            this.vIEWSCANToolStripMenuItem1.Click += new System.EventHandler(this.vIEWSCANToolStripMenuItem1_Click);
            // 
            // mAILERToolStripMenuItem1
            // 
            this.mAILERToolStripMenuItem1.Name = "mAILERToolStripMenuItem1";
            this.mAILERToolStripMenuItem1.ShortcutKeyDisplayString = "F3";
            this.mAILERToolStripMenuItem1.ShortcutKeys = System.Windows.Forms.Keys.F3;
            this.mAILERToolStripMenuItem1.Size = new System.Drawing.Size(246, 24);
            this.mAILERToolStripMenuItem1.Text = "MAILER...";
            this.mAILERToolStripMenuItem1.Click += new System.EventHandler(this.mAILERToolStripMenuItem1_Click);
            // 
            // gETMAILSToolStripMenuItem
            // 
            this.gETMAILSToolStripMenuItem.Name = "gETMAILSToolStripMenuItem";
            this.gETMAILSToolStripMenuItem.ShortcutKeyDisplayString = "F5";
            this.gETMAILSToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this.gETMAILSToolStripMenuItem.Size = new System.Drawing.Size(246, 24);
            this.gETMAILSToolStripMenuItem.Text = "GET MAILS";
            this.gETMAILSToolStripMenuItem.Click += new System.EventHandler(this.gETMAILSToolStripMenuItem_Click);
            // 
            // qUICKEMAILToolStripMenuItem1
            // 
            this.qUICKEMAILToolStripMenuItem1.Name = "qUICKEMAILToolStripMenuItem1";
            this.qUICKEMAILToolStripMenuItem1.ShortcutKeyDisplayString = "F10";
            this.qUICKEMAILToolStripMenuItem1.ShortcutKeys = System.Windows.Forms.Keys.F10;
            this.qUICKEMAILToolStripMenuItem1.Size = new System.Drawing.Size(246, 24);
            this.qUICKEMAILToolStripMenuItem1.Text = "QUICK EMAIL...";
            this.qUICKEMAILToolStripMenuItem1.Click += new System.EventHandler(this.qUICKEMAILToolStripMenuItem1_Click);
            // 
            // cOPYEMAILToolStripMenuItem1
            // 
            this.cOPYEMAILToolStripMenuItem1.Name = "cOPYEMAILToolStripMenuItem1";
            this.cOPYEMAILToolStripMenuItem1.ShortcutKeyDisplayString = "ALT+C";
            this.cOPYEMAILToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.C)));
            this.cOPYEMAILToolStripMenuItem1.Size = new System.Drawing.Size(246, 24);
            this.cOPYEMAILToolStripMenuItem1.Text = "COPY EMAIL";
            this.cOPYEMAILToolStripMenuItem1.Click += new System.EventHandler(this.cOPYEMAILToolStripMenuItem1_Click);
            // 
            // uPDATEToolStripMenuItem
            // 
            this.uPDATEToolStripMenuItem.Name = "uPDATEToolStripMenuItem";
            this.uPDATEToolStripMenuItem.ShortcutKeyDisplayString = "ALT+D";
            this.uPDATEToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.D)));
            this.uPDATEToolStripMenuItem.Size = new System.Drawing.Size(246, 24);
            this.uPDATEToolStripMenuItem.Text = "UPDATE PROFILE";
            this.uPDATEToolStripMenuItem.Click += new System.EventHandler(this.uPDATEToolStripMenuItem_Click);
            // 
            // pROFILEToolStripMenuItem1
            // 
            this.pROFILEToolStripMenuItem1.Name = "pROFILEToolStripMenuItem1";
            this.pROFILEToolStripMenuItem1.ShortcutKeyDisplayString = "ALT+V";
            this.pROFILEToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.V)));
            this.pROFILEToolStripMenuItem1.Size = new System.Drawing.Size(246, 24);
            this.pROFILEToolStripMenuItem1.Text = "VIEW PROFILE...";
            this.pROFILEToolStripMenuItem1.Click += new System.EventHandler(this.pROFILEToolStripMenuItem1_Click);
            // 
            // sETTINGSToolStripMenuItem1
            // 
            this.sETTINGSToolStripMenuItem1.Name = "sETTINGSToolStripMenuItem1";
            this.sETTINGSToolStripMenuItem1.Size = new System.Drawing.Size(246, 24);
            this.sETTINGSToolStripMenuItem1.Text = "SETTINGS...";
            this.sETTINGSToolStripMenuItem1.Click += new System.EventHandler(this.sETTINGSToolStripMenuItem1_Click);
            // 
            // sEARCHToolStripMenuItem
            // 
            this.sEARCHToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bYNAMEToolStripMenuItem,
            this.bYEMAILToolStripMenuItem});
            this.sEARCHToolStripMenuItem.Name = "sEARCHToolStripMenuItem";
            this.sEARCHToolStripMenuItem.Size = new System.Drawing.Size(76, 24);
            this.sEARCHToolStripMenuItem.Text = "&SEARCH";
            // 
            // bYNAMEToolStripMenuItem
            // 
            this.bYNAMEToolStripMenuItem.Name = "bYNAMEToolStripMenuItem";
            this.bYNAMEToolStripMenuItem.ShortcutKeyDisplayString = "CTRL+S";
            this.bYNAMEToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.bYNAMEToolStripMenuItem.Size = new System.Drawing.Size(201, 24);
            this.bYNAMEToolStripMenuItem.Text = "BY NAME";
            this.bYNAMEToolStripMenuItem.Click += new System.EventHandler(this.bYNAMEToolStripMenuItem_Click);
            // 
            // bYEMAILToolStripMenuItem
            // 
            this.bYEMAILToolStripMenuItem.Name = "bYEMAILToolStripMenuItem";
            this.bYEMAILToolStripMenuItem.ShortcutKeyDisplayString = "CTRL+E";
            this.bYEMAILToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.bYEMAILToolStripMenuItem.Size = new System.Drawing.Size(201, 24);
            this.bYEMAILToolStripMenuItem.Text = "BY EMAIL";
            this.bYEMAILToolStripMenuItem.Click += new System.EventHandler(this.bYEMAILToolStripMenuItem_Click);
            // 
            // aBOUTToolStripMenuItem
            // 
            this.aBOUTToolStripMenuItem.Name = "aBOUTToolStripMenuItem";
            this.aBOUTToolStripMenuItem.Size = new System.Drawing.Size(69, 24);
            this.aBOUTToolStripMenuItem.Text = "ABOUT";
            this.aBOUTToolStripMenuItem.Click += new System.EventHandler(this.aBOUTToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1285, 481);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.splitContainer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "lazymail";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.cMenu1.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel1.PerformLayout();
            this.splitContainer4.Panel2.ResumeLayout(false);
            this.splitContainer4.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.SplitContainer splitContainer1;
		private System.Windows.Forms.SplitContainer splitContainer2;
		private System.Windows.Forms.SplitContainer splitContainer3;
		private System.Windows.Forms.SplitContainer splitContainer4;
		private System.Windows.Forms.StatusStrip statusStrip1;
		private System.Windows.Forms.ListView lvemails;
		private System.Windows.Forms.ListView lvstudents;
		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.TextBox txtscanfile;
		private System.Windows.Forms.TextBox txtemailaddress;
		private System.Windows.Forms.TextBox txtName;
		private System.Windows.Forms.ToolStripMenuItem mnuUpdate;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.ColumnHeader columnHeader3;
		private System.Windows.Forms.ColumnHeader columnHeader4;
		private System.Windows.Forms.TextBox txtbody;
		private System.Windows.Forms.ColumnHeader columnHeader8;
		private System.Windows.Forms.ColumnHeader columnHeader9;
		private System.Windows.Forms.ColumnHeader columnHeader10;
		private System.Windows.Forms.ColumnHeader columnHeader11;
		private System.Windows.Forms.TextBox txtsearch;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ToolStripMenuItem sEARCHToolStripMenuItem;
		private System.Windows.Forms.ListBox listImages;
		private System.Windows.Forms.ToolStripStatusLabel sbText;
		private System.Windows.Forms.OpenFileDialog ofd;
		private System.Windows.Forms.FolderBrowserDialog fbd;
		private System.Windows.Forms.ColumnHeader columnHeader6;
		private System.Windows.Forms.ToolStripStatusLabel mailcount;
		private System.Windows.Forms.ToolStripMenuItem bYNAMEToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem bYEMAILToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem uPDATEToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem cOPYEMAILToolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem pROFILEToolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem qUICKEMAILToolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem vIEWSCANToolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem mAILERToolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem sETTINGSToolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem gETMAILSToolStripMenuItem;
		private System.Windows.Forms.ColumnHeader columnHeader5;
		private System.Windows.Forms.ToolStripMenuItem aBOUTToolStripMenuItem;
		private System.Windows.Forms.ToolStripStatusLabel sbSource;
		private System.Windows.Forms.ContextMenuStrip cMenu1;
		private System.Windows.Forms.ToolStripMenuItem rEFERENCEFILEToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem vIEWFILEToolStripMenuItem;
	}
}

