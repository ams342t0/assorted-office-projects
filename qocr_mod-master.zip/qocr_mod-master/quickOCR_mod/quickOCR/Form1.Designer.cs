﻿namespace quickOCR
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fILEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lOADToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rELOADLASTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eXITToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cOMMANDSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cLIPBOARDPASTEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xCAPTUREToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sNAPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cOPYTEXTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cOPYIMAGEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aPPENDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cOPYAPPENDEDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rESETCAMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rOTATERIGHTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rOTATELEFTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tEXTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cLEANUPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cLEANCOPYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cLEANDIGITToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cLEARCOMPILEDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cOPYCOMPILEDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sUDOKUHELPERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dOROWSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mi_get_pattern = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.camview = new System.Windows.Forms.PictureBox();
            this.key_control = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.line_weight = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.selection = new System.Windows.Forms.PictureBox();
            this.txtCompiledText = new System.Windows.Forms.RichTextBox();
            this.richText = new System.Windows.Forms.RichTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbRes = new System.Windows.Forms.ComboBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.cbCamera = new System.Windows.Forms.ComboBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.nBrightness = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.nContrast = new System.Windows.Forms.NumericUpDown();
            this.nCells = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.camview)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.line_weight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.selection)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nBrightness)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nContrast)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nCells)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fILEToolStripMenuItem,
            this.cOMMANDSToolStripMenuItem,
            this.tEXTToolStripMenuItem,
            this.sUDOKUHELPERToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1113, 25);
            this.menuStrip1.TabIndex = 13;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fILEToolStripMenuItem
            // 
            this.fILEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lOADToolStripMenuItem,
            this.rELOADLASTToolStripMenuItem,
            this.eXITToolStripMenuItem});
            this.fILEToolStripMenuItem.Name = "fILEToolStripMenuItem";
            this.fILEToolStripMenuItem.Size = new System.Drawing.Size(42, 21);
            this.fILEToolStripMenuItem.Text = "FILE";
            // 
            // lOADToolStripMenuItem
            // 
            this.lOADToolStripMenuItem.Name = "lOADToolStripMenuItem";
            this.lOADToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.lOADToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.lOADToolStripMenuItem.Text = "LOAD IMAGE...";
            this.lOADToolStripMenuItem.Click += new System.EventHandler(this.lOADToolStripMenuItem_Click);
            // 
            // rELOADLASTToolStripMenuItem
            // 
            this.rELOADLASTToolStripMenuItem.Name = "rELOADLASTToolStripMenuItem";
            this.rELOADLASTToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F1)));
            this.rELOADLASTToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.rELOADLASTToolStripMenuItem.Text = "RELOAD LAST";
            this.rELOADLASTToolStripMenuItem.Click += new System.EventHandler(this.rELOADLASTToolStripMenuItem_Click);
            // 
            // eXITToolStripMenuItem
            // 
            this.eXITToolStripMenuItem.Name = "eXITToolStripMenuItem";
            this.eXITToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.eXITToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.eXITToolStripMenuItem.Text = "EXIT";
            // 
            // cOMMANDSToolStripMenuItem
            // 
            this.cOMMANDSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cLIPBOARDPASTEToolStripMenuItem,
            this.xCAPTUREToolStripMenuItem,
            this.sNAPToolStripMenuItem,
            this.cOPYTEXTToolStripMenuItem,
            this.cOPYIMAGEToolStripMenuItem,
            this.aPPENDToolStripMenuItem,
            this.cOPYAPPENDEDToolStripMenuItem,
            this.rESETCAMToolStripMenuItem,
            this.rOTATERIGHTToolStripMenuItem,
            this.rOTATELEFTToolStripMenuItem});
            this.cOMMANDSToolStripMenuItem.Name = "cOMMANDSToolStripMenuItem";
            this.cOMMANDSToolStripMenuItem.Size = new System.Drawing.Size(96, 21);
            this.cOMMANDSToolStripMenuItem.Text = "COMMANDS";
            // 
            // cLIPBOARDPASTEToolStripMenuItem
            // 
            this.cLIPBOARDPASTEToolStripMenuItem.Name = "cLIPBOARDPASTEToolStripMenuItem";
            this.cLIPBOARDPASTEToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.cLIPBOARDPASTEToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.cLIPBOARDPASTEToolStripMenuItem.Text = "CLIPBOARD PASTE";
            this.cLIPBOARDPASTEToolStripMenuItem.Click += new System.EventHandler(this.cLIPBOARDPASTEToolStripMenuItem_Click);
            // 
            // xCAPTUREToolStripMenuItem
            // 
            this.xCAPTUREToolStripMenuItem.Name = "xCAPTUREToolStripMenuItem";
            this.xCAPTUREToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F3;
            this.xCAPTUREToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.xCAPTUREToolStripMenuItem.Text = "CAPTURE";
            this.xCAPTUREToolStripMenuItem.Click += new System.EventHandler(this.xCAPTUREToolStripMenuItem_Click);
            // 
            // sNAPToolStripMenuItem
            // 
            this.sNAPToolStripMenuItem.Name = "sNAPToolStripMenuItem";
            this.sNAPToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F4;
            this.sNAPToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.sNAPToolStripMenuItem.Text = "SNAP";
            this.sNAPToolStripMenuItem.Click += new System.EventHandler(this.sNAPToolStripMenuItem_Click);
            // 
            // cOPYTEXTToolStripMenuItem
            // 
            this.cOPYTEXTToolStripMenuItem.Name = "cOPYTEXTToolStripMenuItem";
            this.cOPYTEXTToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this.cOPYTEXTToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.cOPYTEXTToolStripMenuItem.Text = "COPY TEXT";
            this.cOPYTEXTToolStripMenuItem.Click += new System.EventHandler(this.cOPYTEXTToolStripMenuItem_Click);
            // 
            // cOPYIMAGEToolStripMenuItem
            // 
            this.cOPYIMAGEToolStripMenuItem.Name = "cOPYIMAGEToolStripMenuItem";
            this.cOPYIMAGEToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F6;
            this.cOPYIMAGEToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.cOPYIMAGEToolStripMenuItem.Text = "COPY IMAGE";
            this.cOPYIMAGEToolStripMenuItem.Click += new System.EventHandler(this.cOPYIMAGEToolStripMenuItem_Click);
            // 
            // aPPENDToolStripMenuItem
            // 
            this.aPPENDToolStripMenuItem.Name = "aPPENDToolStripMenuItem";
            this.aPPENDToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F7;
            this.aPPENDToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.aPPENDToolStripMenuItem.Text = "APPEND";
            this.aPPENDToolStripMenuItem.Click += new System.EventHandler(this.aPPENDToolStripMenuItem_Click);
            // 
            // cOPYAPPENDEDToolStripMenuItem
            // 
            this.cOPYAPPENDEDToolStripMenuItem.Name = "cOPYAPPENDEDToolStripMenuItem";
            this.cOPYAPPENDEDToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F8;
            this.cOPYAPPENDEDToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.cOPYAPPENDEDToolStripMenuItem.Text = "COPY APPENDED";
            this.cOPYAPPENDEDToolStripMenuItem.Click += new System.EventHandler(this.cOPYAPPENDEDToolStripMenuItem_Click);
            // 
            // rESETCAMToolStripMenuItem
            // 
            this.rESETCAMToolStripMenuItem.Name = "rESETCAMToolStripMenuItem";
            this.rESETCAMToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F10;
            this.rESETCAMToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.rESETCAMToolStripMenuItem.Text = "RESETCAM";
            this.rESETCAMToolStripMenuItem.Click += new System.EventHandler(this.rESETCAMToolStripMenuItem_Click);
            // 
            // rOTATERIGHTToolStripMenuItem
            // 
            this.rOTATERIGHTToolStripMenuItem.Name = "rOTATERIGHTToolStripMenuItem";
            this.rOTATERIGHTToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl++";
            this.rOTATERIGHTToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Oemplus)));
            this.rOTATERIGHTToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.rOTATERIGHTToolStripMenuItem.Text = "ROTATE RIGHT";
            this.rOTATERIGHTToolStripMenuItem.Click += new System.EventHandler(this.rOTATERIGHTToolStripMenuItem_Click);
            // 
            // rOTATELEFTToolStripMenuItem
            // 
            this.rOTATELEFTToolStripMenuItem.Name = "rOTATELEFTToolStripMenuItem";
            this.rOTATELEFTToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl+-";
            this.rOTATELEFTToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.OemMinus)));
            this.rOTATELEFTToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.rOTATELEFTToolStripMenuItem.Text = "ROTATE LEFT";
            this.rOTATELEFTToolStripMenuItem.Click += new System.EventHandler(this.rOTATELEFTToolStripMenuItem_Click);
            // 
            // tEXTToolStripMenuItem
            // 
            this.tEXTToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cLEANUPToolStripMenuItem,
            this.cLEANCOPYToolStripMenuItem,
            this.cLEANDIGITToolStripMenuItem,
            this.cLEARCOMPILEDToolStripMenuItem,
            this.cOPYCOMPILEDToolStripMenuItem});
            this.tEXTToolStripMenuItem.Name = "tEXTToolStripMenuItem";
            this.tEXTToolStripMenuItem.Size = new System.Drawing.Size(49, 21);
            this.tEXTToolStripMenuItem.Text = "TEXT";
            // 
            // cLEANUPToolStripMenuItem
            // 
            this.cLEANUPToolStripMenuItem.Name = "cLEANUPToolStripMenuItem";
            this.cLEANUPToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.cLEANUPToolStripMenuItem.Size = new System.Drawing.Size(258, 22);
            this.cLEANUPToolStripMenuItem.Text = "CLEAN UP";
            this.cLEANUPToolStripMenuItem.Click += new System.EventHandler(this.cLEANUPToolStripMenuItem_Click);
            // 
            // cLEANCOPYToolStripMenuItem
            // 
            this.cLEANCOPYToolStripMenuItem.Name = "cLEANCOPYToolStripMenuItem";
            this.cLEANCOPYToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Alt)
                        | System.Windows.Forms.Keys.C)));
            this.cLEANCOPYToolStripMenuItem.Size = new System.Drawing.Size(258, 22);
            this.cLEANCOPYToolStripMenuItem.Text = "COPY CLEAN";
            this.cLEANCOPYToolStripMenuItem.Click += new System.EventHandler(this.cLEANCOPYToolStripMenuItem_Click);
            // 
            // cLEANDIGITToolStripMenuItem
            // 
            this.cLEANDIGITToolStripMenuItem.Name = "cLEANDIGITToolStripMenuItem";
            this.cLEANDIGITToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
                        | System.Windows.Forms.Keys.C)));
            this.cLEANDIGITToolStripMenuItem.Size = new System.Drawing.Size(258, 22);
            this.cLEANDIGITToolStripMenuItem.Text = "CLEAN DIGIT";
            this.cLEANDIGITToolStripMenuItem.Click += new System.EventHandler(this.cLEANDIGITToolStripMenuItem_Click);
            // 
            // cLEARCOMPILEDToolStripMenuItem
            // 
            this.cLEARCOMPILEDToolStripMenuItem.Name = "cLEARCOMPILEDToolStripMenuItem";
            this.cLEARCOMPILEDToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
                        | System.Windows.Forms.Keys.X)));
            this.cLEARCOMPILEDToolStripMenuItem.Size = new System.Drawing.Size(258, 22);
            this.cLEARCOMPILEDToolStripMenuItem.Text = "CLEAR COMPILED";
            this.cLEARCOMPILEDToolStripMenuItem.Click += new System.EventHandler(this.cLEARCOMPILEDToolStripMenuItem_Click);
            // 
            // cOPYCOMPILEDToolStripMenuItem
            // 
            this.cOPYCOMPILEDToolStripMenuItem.Name = "cOPYCOMPILEDToolStripMenuItem";
            this.cOPYCOMPILEDToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.cOPYCOMPILEDToolStripMenuItem.Size = new System.Drawing.Size(258, 22);
            this.cOPYCOMPILEDToolStripMenuItem.Text = "COPY COMPILED";
            this.cOPYCOMPILEDToolStripMenuItem.Click += new System.EventHandler(this.cOPYCOMPILEDToolStripMenuItem_Click);
            // 
            // sUDOKUHELPERToolStripMenuItem
            // 
            this.sUDOKUHELPERToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dOROWSToolStripMenuItem,
            this.mi_get_pattern});
            this.sUDOKUHELPERToolStripMenuItem.Name = "sUDOKUHELPERToolStripMenuItem";
            this.sUDOKUHELPERToolStripMenuItem.Size = new System.Drawing.Size(120, 21);
            this.sUDOKUHELPERToolStripMenuItem.Text = "SUDOKU HELPER";
            // 
            // dOROWSToolStripMenuItem
            // 
            this.dOROWSToolStripMenuItem.Name = "dOROWSToolStripMenuItem";
            this.dOROWSToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D)));
            this.dOROWSToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.dOROWSToolStripMenuItem.Text = "DO ROWS";
            this.dOROWSToolStripMenuItem.Click += new System.EventHandler(this.dOROWSToolStripMenuItem_Click);
            // 
            // mi_get_pattern
            // 
            this.mi_get_pattern.Name = "mi_get_pattern";
            this.mi_get_pattern.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.G)));
            this.mi_get_pattern.Size = new System.Drawing.Size(203, 22);
            this.mi_get_pattern.Text = "GET PATTERN";
            this.mi_get_pattern.Click += new System.EventHandler(this.mi_get_pattern_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(0, 27);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.camview);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.key_control);
            this.splitContainer1.Panel2.Controls.Add(this.groupBox3);
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer1.Size = new System.Drawing.Size(1113, 490);
            this.splitContainer1.SplitterDistance = 522;
            this.splitContainer1.TabIndex = 14;
            // 
            // camview
            // 
            this.camview.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.camview.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.camview.Location = new System.Drawing.Point(3, 3);
            this.camview.Name = "camview";
            this.camview.Size = new System.Drawing.Size(516, 484);
            this.camview.TabIndex = 1;
            this.camview.TabStop = false;
            this.camview.MouseDown += new System.Windows.Forms.MouseEventHandler(this.camview_MouseDown);
            this.camview.MouseMove += new System.Windows.Forms.MouseEventHandler(this.camview_MouseMove);
            this.camview.MouseUp += new System.Windows.Forms.MouseEventHandler(this.camview_MouseUp);
            this.camview.Resize += new System.EventHandler(this.camview_Resize);
            // 
            // key_control
            // 
            this.key_control.BackColor = System.Drawing.SystemColors.Control;
            this.key_control.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.key_control.Cursor = System.Windows.Forms.Cursors.Default;
            this.key_control.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.key_control.Location = new System.Drawing.Point(426, 9);
            this.key_control.Name = "key_control";
            this.key_control.Size = new System.Drawing.Size(25, 13);
            this.key_control.TabIndex = 17;
            this.key_control.KeyDown += new System.Windows.Forms.KeyEventHandler(this.key_control_KeyDown);
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.nCells);
            this.groupBox3.Controls.Add(this.line_weight);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.checkBox1);
            this.groupBox3.Location = new System.Drawing.Point(310, 1);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(274, 77);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Sudoku Helper";
            // 
            // line_weight
            // 
            this.line_weight.Location = new System.Drawing.Point(72, 42);
            this.line_weight.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.line_weight.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.line_weight.Name = "line_weight";
            this.line_weight.Size = new System.Drawing.Size(67, 20);
            this.line_weight.TabIndex = 18;
            this.line_weight.Value = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.line_weight.ValueChanged += new System.EventHandler(this.line_weight_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(2, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "Line Weight";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(6, 20);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(94, 17);
            this.checkBox1.TabIndex = 17;
            this.checkBox1.Text = "DIGITS ONLY";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer2.Location = new System.Drawing.Point(3, 80);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.selection);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.txtCompiledText);
            this.splitContainer2.Panel2.Controls.Add(this.richText);
            this.splitContainer2.Size = new System.Drawing.Size(581, 413);
            this.splitContainer2.SplitterDistance = 182;
            this.splitContainer2.TabIndex = 16;
            // 
            // selection
            // 
            this.selection.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.selection.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.selection.Location = new System.Drawing.Point(0, 4);
            this.selection.Name = "selection";
            this.selection.Size = new System.Drawing.Size(581, 175);
            this.selection.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.selection.TabIndex = 13;
            this.selection.TabStop = false;
            // 
            // txtCompiledText
            // 
            this.txtCompiledText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCompiledText.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCompiledText.Location = new System.Drawing.Point(0, 124);
            this.txtCompiledText.Name = "txtCompiledText";
            this.txtCompiledText.Size = new System.Drawing.Size(581, 97);
            this.txtCompiledText.TabIndex = 16;
            this.txtCompiledText.Text = "";
            // 
            // richText
            // 
            this.richText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.richText.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richText.Location = new System.Drawing.Point(0, 3);
            this.richText.Name = "richText";
            this.richText.Size = new System.Drawing.Size(581, 115);
            this.richText.TabIndex = 14;
            this.richText.Text = "";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.cbRes);
            this.groupBox1.Controls.Add(this.radioButton3);
            this.groupBox1.Controls.Add(this.cbCamera);
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Controls.Add(this.nBrightness);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.nContrast);
            this.groupBox1.Location = new System.Drawing.Point(3, 1);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(432, 77);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Adjust";
            // 
            // cbRes
            // 
            this.cbRes.FormattingEnabled = true;
            this.cbRes.Location = new System.Drawing.Point(148, 40);
            this.cbRes.Name = "cbRes";
            this.cbRes.Size = new System.Drawing.Size(149, 21);
            this.cbRes.TabIndex = 16;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(110, 56);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(31, 17);
            this.radioButton3.TabIndex = 11;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "3";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // cbCamera
            // 
            this.cbCamera.FormattingEnabled = true;
            this.cbCamera.Location = new System.Drawing.Point(148, 13);
            this.cbCamera.Name = "cbCamera";
            this.cbCamera.Size = new System.Drawing.Size(149, 21);
            this.cbCamera.TabIndex = 15;
            this.cbCamera.SelectedIndexChanged += new System.EventHandler(this.cbCamera_SelectedIndexChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(110, 33);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(31, 17);
            this.radioButton2.TabIndex = 10;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "2";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(110, 10);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(31, 17);
            this.radioButton1.TabIndex = 9;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "1";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // nBrightness
            // 
            this.nBrightness.Location = new System.Drawing.Point(68, 19);
            this.nBrightness.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.nBrightness.Minimum = new decimal(new int[] {
            200,
            0,
            0,
            -2147483648});
            this.nBrightness.Name = "nBrightness";
            this.nBrightness.Size = new System.Drawing.Size(36, 20);
            this.nBrightness.TabIndex = 5;
            this.nBrightness.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nBrightness.ValueChanged += new System.EventHandler(this.nBrightness_ValueChanged_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Contrast";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Brightness";
            // 
            // nContrast
            // 
            this.nContrast.Location = new System.Drawing.Point(68, 45);
            this.nContrast.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.nContrast.Minimum = new decimal(new int[] {
            200,
            0,
            0,
            -2147483648});
            this.nContrast.Name = "nContrast";
            this.nContrast.Size = new System.Drawing.Size(36, 20);
            this.nContrast.TabIndex = 7;
            this.nContrast.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // nCells
            // 
            this.nCells.Location = new System.Drawing.Point(201, 17);
            this.nCells.Maximum = new decimal(new int[] {
            27,
            0,
            0,
            0});
            this.nCells.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.nCells.Name = "nCells";
            this.nCells.Size = new System.Drawing.Size(36, 20);
            this.nCells.TabIndex = 17;
            this.nCells.Value = new decimal(new int[] {
            9,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(116, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Rows/Columns";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1113, 517);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "QOCR";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.camview)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.line_weight)).EndInit();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.selection)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nBrightness)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nContrast)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nCells)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fILEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lOADToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cOMMANDSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xCAPTUREToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sNAPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cOPYTEXTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cOPYIMAGEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aPPENDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eXITToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.PictureBox camview;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.NumericUpDown nBrightness;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nContrast;
        private System.Windows.Forms.ToolStripMenuItem tEXTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cLEANUPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cOPYAPPENDEDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cLEANCOPYToolStripMenuItem;
        private System.Windows.Forms.ComboBox cbCamera;
        private System.Windows.Forms.ComboBox cbRes;
        private System.Windows.Forms.ToolStripMenuItem rESETCAMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cLIPBOARDPASTEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rELOADLASTToolStripMenuItem;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.ToolStripMenuItem cLEANDIGITToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cLEARCOMPILEDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cOPYCOMPILEDToolStripMenuItem;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.PictureBox selection;
        private System.Windows.Forms.RichTextBox txtCompiledText;
        private System.Windows.Forms.RichTextBox richText;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ToolStripMenuItem sUDOKUHELPERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dOROWSToolStripMenuItem;
        private System.Windows.Forms.NumericUpDown line_weight;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStripMenuItem mi_get_pattern;
        private System.Windows.Forms.TextBox key_control;
        private System.Windows.Forms.ToolStripMenuItem rOTATERIGHTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rOTATELEFTToolStripMenuItem;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nCells;
    }
}

