# scoresheet
a sudoku contest scoresheet
